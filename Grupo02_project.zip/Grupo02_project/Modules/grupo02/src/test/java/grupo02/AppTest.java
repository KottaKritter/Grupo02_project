package grupo02;

import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class AppTest 
{

}
