package grupo02;

public class Diagnosis {
}
